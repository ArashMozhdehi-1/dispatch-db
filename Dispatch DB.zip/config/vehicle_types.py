# Vehicle types from enum units.csv - only actual vehicle types
VEHICLE_UNIT_TYPES = {
    249: "Truck",
    250: "Shovel",
    251: "Dump",
    260: "Drill",
    261: "Dozer",
    262: "Grader",
    263: "Wheel Dozer",
    265: "Foreman",
    266: "Water Truck",
    267: "Utility Vehicle",
    268: "Man Bus",
    269: "Generic Auxil",
}
