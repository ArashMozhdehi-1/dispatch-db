INFRASTRUCTURE_UNIT_TYPES = {
    252: "Crusher",
    253: "Stockpile", 
    254: "Blast",
    255: "Workshop",
    257: "Call Point",
    260: "Drill",
    264: "Aux Crusher",
    1131: "Fuelbay"
}

VEHICLE_UNIT_TYPES = {
    249: "Truck",
    250: "Shovel",
    251: "Dump",
    261: "Dozer",
    262: "Grader",
    263: "Wheel Dozer",
    265: "Foreman",
    266: "Water Truck",
    267: "Utility Vehicle",
    268: "Man Bus",
    269: "Generic Auxil"
}

SHOP_UNIT_TYPES = {
    255: "Workshop"
}

SHOP_TYPE_MAPPING = {
    226: "Maint Workshop",
    227: "Fuel Workshop", 
    228: "Tyre Workshop",
    229: "Other Workshop",
    231: "Water Fill",
    232: "Weigh Station"
}
